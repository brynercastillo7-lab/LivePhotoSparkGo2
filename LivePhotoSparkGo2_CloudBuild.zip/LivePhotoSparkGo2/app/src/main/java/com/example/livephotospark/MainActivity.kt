package com.example.livephotospark

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var flipButton: Button
    private lateinit var statusText: TextView
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var useFrontCamera = false
    private var busy = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Camera permission is required to take Live Photos."
            captureButton.isEnabled = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 12)
            setBackgroundColor(0x66000000)
        }
        top.addView(TextView(this).apply {
            text = "LIVE PHOTO"
            textSize = 20f
            setTextColor(-1)
            letterSpacing = 0.12f
        })
        statusText = TextView(this).apply {
            text = "Photo + short motion clip"
            textSize = 13f
            setTextColor(0xFFE0E0E0.toInt())
            setPadding(0, 5, 0, 0)
        }
        top.addView(statusText)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 16, 18, 26)
            setBackgroundColor(0x66000000)
        }
        captureButton = Button(this).apply {
            text = "●  CAPTURE LIVE PHOTO"
            textSize = 15f
            isAllCaps = false
            setOnClickListener { captureLivePhoto() }
        }
        bottom.addView(captureButton, LinearLayout.LayoutParams(-1, -2))
        flipButton = Button(this).apply {
            text = "Switch camera"
            isAllCaps = false
            setOnClickListener {
                if (!busy) {
                    useFrontCamera = !useFrontCamera
                    startCamera()
                }
            }
        }
        bottom.addView(flipButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (!provider.hasCamera(selector)) {
                    Toast.makeText(this, "That camera is not available.", Toast.LENGTH_SHORT).show()
                    useFrontCamera = false
                    return@addListener
                }
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.SD))
                    .build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, imageCapture, videoCapture)
                statusText.text = "Ready · photo and 3-second motion clip"
                captureButton.isEnabled = true
            } catch (e: Exception) {
                statusText.text = "Camera could not start: ${e.localizedMessage ?: "unsupported camera mode"}"
                captureButton.isEnabled = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureLivePhoto() {
        val still = imageCapture ?: return
        val video = videoCapture ?: return
        if (busy) return
        busy = true
        captureButton.isEnabled = false
        flipButton.isEnabled = false
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val photoName = "LIVE_$stamp.jpg"
        val videoName = "LIVE_${stamp}_motion.mp4"
        statusText.text = "Saving photo…"

        val photoValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, photoName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LivePhoto")
        }
        val photoOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, photoValues
        ).build()

        still.takePicture(photoOptions, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                runOnUiThread { statusText.text = "Photo saved · recording motion clip…" }
                startMotionClip(video, stamp, videoName)
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    busy = false
                    captureButton.isEnabled = true
                    flipButton.isEnabled = true
                    statusText.text = "Photo failed: ${exception.message ?: "camera error"}"
                }
            }
        })
    }

    private fun startMotionClip(video: VideoCapture<Recorder>, stamp: String, videoName: String) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, videoName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/LivePhoto")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            activeRecording = video.output.prepareRecording(this, output).start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Start) {
                    statusText.text = "Recording motion…"
                    previewView.postDelayed({ activeRecording?.stop() }, 3000L)
                } else if (event is VideoRecordEvent.Finalize) {
                    activeRecording = null
                    busy = false
                    captureButton.isEnabled = true
                    flipButton.isEnabled = true
                    statusText.text = if (event.hasError()) "Photo saved; motion clip failed." else "Live Photo saved! Find JPG in Pictures/LivePhoto and MP4 in Movies/LivePhoto."
                    Toast.makeText(this, if (event.hasError()) "Still photo saved; motion clip failed" else "Live Photo saved", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            busy = false
            captureButton.isEnabled = true
            flipButton.isEnabled = true
            statusText.text = "Photo saved, but video recording isn't supported in this camera mode."
        }
    }

    override fun onDestroy() {
        activeRecording?.stop()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
