# Live Photo for TECNO SPARK GO 2 (starter Android app)

This Android Studio project creates a simple CameraX app that saves a full-resolution still photo and a separate 3-second MP4 motion clip with matching timestamps. It is a practical Live Photo-style workaround; it does **not** create Apple's proprietary Live Photo format or combine the image and clip into one animated gallery item.

## Build
1. Install Android Studio on a computer and allow it to install Android SDK 35 and a compatible JDK (Android Studio's bundled JDK is fine).
2. Open this folder as an existing Android Studio project.
3. Let Gradle sync, then choose **Build > Build APK(s)**.
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to the phone and install it. If Android asks, allow installs from the file manager you use.
5. Open **Live Photo** and allow camera permission.

## On the phone
- Tap **CAPTURE LIVE PHOTO**. It saves a JPG under `Pictures/LivePhoto` and a 3-second MP4 under `Movies/LivePhoto`, using matching timestamps.
- The camera can fail to bind still capture and video capture together on some device camera implementations. If that happens on this phone, the app reports the error rather than claiming it worked.
- The motion clip is recorded immediately after the still photo, so it doesn't include moments from before the shutter. A true pre-and-post capture implementation needs a rolling video buffer and device-specific testing.

## Notes
- This source project has not been compiled or tested on the TECNO SPARK GO 2 in this environment. Device compatibility must be verified on the phone.
